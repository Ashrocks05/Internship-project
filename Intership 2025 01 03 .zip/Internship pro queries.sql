--CREATE TABLE Users (
--UserID INT PRIMARY KEY IDENTITY(1,1),
--UserName NVARCHAR(100) NOT NULL
--);

SELECT * FROM Users;

--CREATE TABLE Roles (
--RoleID INT PRIMARY KEY IDENTITY(1,2),
--RoleName NVARCHAR(50) not null
--);

SELECT* FROM Roles;

--CREATE TABLE UserRoles (
--UserRoleID INT PRIMARY KEY IDENTITY(1,1),
--UserID INT FOREIGN KEY REFERENCES Users(UserID) ON DELETE CASCADE, 
--RoleID INT FOREIGN KEY REFERENCES Roles(RoleID) ON DELETE CASCADE, 
--);

SELECT* FROM UserRoles;


Begin Transaction 
--Insert into Users(Username)
--Values('Ash'),('Pa')
--Insert into Roles(Rolename)
--Values('Admin'),('Editor')





Insert into UserRoles(UserID,RoleID)
Values
(1,1),
(1,3)

Delete from Users 

Commit
rollback



select * from users where userid = 1 OR username = 'Parag'


--C - CREATE
--R = Read
--U - Update
--D - Delete





select * from users u
join UserRoles ur on ur.userid = u.userid
join roles r on r.roleid = ur.roleid
