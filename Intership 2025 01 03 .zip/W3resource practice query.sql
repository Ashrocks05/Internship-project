select * from employees;
select * from departments;
select * from countries;
select * from jobs;



select job_id from employees;
select salary,salary*1.15 incsalary from employees;
SELECT first_name,
       FORMAT(1.15 * salary, 'C', 'en-US') AS Salary
FROM employees;
select first_name employee,job_id job from employees;
SELECT first_name + '   ' + job_id AS [Employee & Job]
FROM employees;

SELECT first_name + '(' + LOWER(job_id) + ')' AS [Employee]
FROM employees;

SELECT first_name +'   ' + job_id AS "Employee & Job"
FROM employees ;

SELECT EMPLOYEE_ID,FIRST_NAME,SALARY,HIRE_DATE,convert(varchar,hire_date, 107) AS HireDate 
FROM EMPLOYEES;

SELECT LEN(first_name) AS LengthOfFirstName
FROM employees;

SELECT DISTINCT DEPARTMENT_ID, JOB_ID
FROM employees;

SELECT *
FROM employees
WHERE hire_date<('1991-1-1');

SELECT *
FROM employees
WHERE commission_pct>salary;

SELECT *
FROM employees
WHERE (1.25*salary) > 3000;

SELECT FIRST_NAME
FROM employees
WHERE LEN(FIRST_NAME)=6




